-- full-border plugin
require("full-border"):setup({
	type = ui.Border.ROUNDED,
})

-- git plugin
require("git"):setup({
	order = 1500,
})

-- mactag is backed by Finder tags and only exists on macOS. The portable
-- adapter makes this setup a no-op elsewhere while keeping one shared config.
require("mactag-portable"):setup({
	-- Keys used to add or remove tags
	keys = {
		r = "Red",
		o = "Orange",
		y = "Yellow",
		g = "Green",
		b = "Blue",
		p = "Purple",
	},
	-- Colors used to display tags
	colors = {
		Red = "#ee7b70",
		Orange = "#f5bd5c",
		Yellow = "#fbe764",
		Green = "#91fc87",
		Blue = "#5fa3f8",
		Purple = "#cb88f8",
	},
	-- Order of the color circle showing in the line mode
	order = 500,
})

-- easyjump plugin
require("easyjump"):setup({
	-- example customization - you can choose your own keys
	first_keys = "asdfgercwtvxbq", -- 14 keys
	second_keys = "yuiophjklnm", -- 11 keys
})
