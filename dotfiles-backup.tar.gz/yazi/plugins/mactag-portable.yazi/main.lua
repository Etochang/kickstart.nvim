--- Keep Finder tags on macOS without breaking the shared config on Windows.
--- The package-managed mactag plugin remains the implementation on macOS;
--- every other platform delegates fetches to Yazi's built-in no-op plugin.

local M = {}
local is_macos = ya.target_os() == "macos"

function M:setup(opts)
	if is_macos then
		require("mactag"):setup(opts)
	end
end

function M:fetch(job)
	if is_macos then
		return require("mactag"):fetch(job)
	end

	return require("noop"):fetch(job)
end

function M:entry(job)
	if is_macos then
		return require("mactag"):entry(job)
	end
end

return M
