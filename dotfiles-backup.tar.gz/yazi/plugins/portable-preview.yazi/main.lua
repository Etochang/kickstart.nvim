--- Preserve the enhanced piper previews on Unix and use Yazi's built-in
--- previewers on Windows, where piper's required POSIX `sh` is not standard.

local M = {}

local previews = {
	archive = {
		command = 'ouch list --tree "$1"',
		fallback = "archive",
	},
	csv = {
		command = 'bat -p --color=always "$1"',
		fallback = "code",
	},
	markdown = {
		command = 'CLICOLOR_FORCE=1 glow -w=$w -s=dark "$1"',
		fallback = "code",
	},
	sqlite = {
		command = 'sqlite3 "$1" ".schema --indent"',
		fallback = "code",
	},
	directory = {
		command = 'eza -TL=3 --color=always --icons=always --group-directories-first --no-quotes "$1"',
		fallback = "folder",
	},
	hex = {
		command = 'hexyl --border=none --terminal-width=$w "$1"',
		fallback = "code",
	},
}

local function selected_preview(job)
	local name = job.args[1]
	return previews[name] or previews.hex
end

local function with_args(job, args)
	local copy = {}
	for key, value in pairs(job) do
		copy[key] = value
	end
	copy.args = args
	return copy
end

function M:peek(job)
	local preview = selected_preview(job)
	if ya.target_family() == "unix" then
		return require("piper"):peek(with_args(job, { preview.command }))
	end

	return require(preview.fallback):peek(with_args(job, {}))
end

function M:seek(job)
	local preview = selected_preview(job)
	return require(ya.target_family() == "unix" and "piper" or preview.fallback):seek(with_args(job, {}))
end

return M
