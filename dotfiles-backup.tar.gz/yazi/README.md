# Portable Yazi configuration

This repository contains the shared Yazi configuration used on macOS and
native Windows. The tracked `package.toml` locks third-party plugins; their
generated directories are intentionally ignored and restored with
`ya pkg install`.

## What is tracked

- `yazi.toml`: openers, file rules, Git metadata, and preview rules
- `keymap.toml`: custom keybindings layered on top of Yazi's defaults
- `init.lua`: plugin setup
- `package.toml`: locked plugin sources, revisions, and hashes
- `plugins/mactag-portable.yazi`: makes Finder tags a macOS-only feature
- `plugins/portable-preview.yazi`: uses enhanced Unix previews and safe
  built-in Windows fallbacks

The downloaded plugin directories under `plugins/` and all downloaded flavors
are not tracked. Do not copy them manually between machines.

## Install on macOS or Linux

Back up an existing configuration, clone this repository into Yazi's default
configuration directory, and restore the locked plugins:

```sh
config_home="${XDG_CONFIG_HOME:-$HOME/.config}/yazi"
if [ -e "$config_home" ]; then
  mv "$config_home" "$config_home.backup-$(date +%Y%m%d-%H%M%S)"
fi
git clone <your-repository-url> "$config_home"
cd "$config_home"
ya pkg install
ya env
```

On macOS, the enhanced preview commands currently use `ouch`, `bat`, `glow`,
`sqlite3`, `eza`, and `hexyl`. Install whichever previews you want to use.
Finder tags additionally require the `tag` executable.

## Install on Windows

Yazi uses `%AppData%\yazi\config` rather than Neovim's `%LocalAppData%`
directory. In PowerShell 7:

```powershell
$config = Join-Path $env:APPDATA "yazi\config"
$backup = "$config.backup-$(Get-Date -Format yyyyMMdd-HHmmss)"

if (Test-Path $config) {
    Move-Item $config $backup
}

git clone <your-repository-url> $config
Set-Location $config
ya pkg install
ya env
```

Install Yazi and Git for Windows first:

```powershell
winget install --id sxyazi.yazi -e --source winget
winget install --id Git.Git -e --source winget
```

Yazi uses Git for Windows' `file.exe` for reliable MIME detection. Set it for
the current shell and persist it for future shells:

```powershell
$fileOne = "$env:ProgramFiles\Git\usr\bin\file.exe"
$env:YAZI_FILE_ONE = $fileOne
[Environment]::SetEnvironmentVariable("YAZI_FILE_ONE", $fileOne, "User")
```

Restart the terminal after changing a persistent environment variable. The
Windows openers expect both `nvim` and the VS Code `code` command on `PATH`.
Custom piper previews fall back to Yazi's built-in archive, folder, and code
previewers on Windows, so a POSIX shell is not required.

Optional Windows preview/search dependencies can be installed with:

```powershell
winget install --id 7zip.7zip -e --source winget
winget install --id sharkdp.fd -e --source winget
winget install --id BurntSushi.ripgrep.MSVC -e --source winget
winget install --id junegunn.fzf -e --source winget
winget install --id jqlang.jq -e --source winget
winget install --id ajeetdsouza.zoxide -e --source winget
```

Use matching `yazi` and `ya` versions, at least 26.8.15. Keep Yazi reasonably
current because its plugin API is still evolving.

## Custom keybindings

| Keys | Action | Platforms |
| --- | --- | --- |
| `l` | Enter a directory or open the hovered file | All |
| `T` | Toggle a maximized preview pane | All |
| `i` | Jump directly to a visible entry | All |
| `F` | Start the smart filter | All |
| `b a` | Add a Finder color tag | macOS only |
| `b r` | Remove a Finder color tag | macOS only |

All normal Yazi bindings remain available because the custom bindings use
`prepend_keymap` rather than replacing the default keymap.

## Plugin maintenance

```sh
ya pkg list
ya pkg install
ya pkg upgrade
```

After adding, deleting, or upgrading a package, commit the resulting change to
`package.toml`. A newly cloned machine then reproduces those locked revisions
with `ya pkg install`.

## Publishing this repository

The local repository already has its initial commit. Create an empty remote
repository and connect it:

```sh
git remote add origin <your-repository-url>
git push -u origin main
```

With GitHub CLI, those last two steps can instead be performed with:

```sh
gh repo create yazi-config --private --source=. --remote=origin --push
```

## Caveats

- `mactag` and its `b a` / `b r` bindings intentionally do nothing outside
  macOS because Windows has no Finder tags.
- The Windows PDF rule opens the selected file in its registered default app;
  macOS continues to use Adobe Acrobat.
- Image previews depend on terminal support. Use a current Windows Terminal,
  WezTerm, or another terminal supported by Yazi.
- `<D-...>` represents Command on macOS and the Windows/Super key on Windows;
  terminal support for those modified keys varies.
- Creating symbolic links from Yazi can require elevated privileges on
  Windows.
- Native Windows and WSL have different configuration roots and environments.
